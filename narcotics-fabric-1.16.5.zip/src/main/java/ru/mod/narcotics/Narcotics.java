package ru.mod.narcotics;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.client.itemgroup.FabricItemGroupBuilder;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;
import ru.mod.narcotics.block.ModBlocks;
import ru.mod.narcotics.drug.DrugManager;
import ru.mod.narcotics.effect.ModEffects;
import ru.mod.narcotics.item.ModItems;

public class Narcotics implements ModInitializer {
    public static final String MODID = "narcotics";

    public static final ItemGroup GROUP = FabricItemGroupBuilder.build(
            new Identifier(MODID, "main"), () -> new ItemStack(ModItems.SYRINGE_EMPTY));

    public static Identifier id(String path) {
        return new Identifier(MODID, path);
    }

    @Override
    public void onInitialize() {
        ModEffects.register();
        ModItems.register();
        ModBlocks.register();
        DrugManager.init();
    }
}
