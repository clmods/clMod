package ru.mod.narcotics.effect;

import java.nio.charset.StandardCharsets;
import java.util.UUID;

import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectType;
import net.minecraft.util.registry.Registry;
import ru.mod.narcotics.Narcotics;
import ru.mod.narcotics.drug.Phase;
import ru.mod.narcotics.drug.Substance;

public final class ModEffects {
    private static final int[] COLORS = {0xE8E8E8, 0x3FA83F, 0x6B7FD6, 0xD6A66B};

    /** {movement speed, attack speed} multipliers per substance and phase. */
    private static final double[][][] MODS = {
            /* STIMULANT    */ {{0.30, 0.15}, {0.15, 0.0}, {-0.20, -0.10}},
            /* HALLUCINOGEN */ {{0.0, 0.0}, {0.0, 0.0}, {0.0, -0.10}},
            /* DEPRESSANT   */ {{-0.15, 0.0}, {-0.10, 0.0}, {-0.10, -0.20}},
            /* OPIOID       */ {{-0.20, 0.0}, {-0.10, 0.0}, {-0.10, -0.15}}
    };

    private static final StatusEffect[][] EFFECTS = new StatusEffect[Substance.COUNT][3];

    public static final StatusEffect WITHDRAWAL = new WithdrawalEffect();

    static {
        for (Substance s : Substance.VALUES) {
            for (Phase p : Phase.values()) {
                EFFECTS[s.ordinal()][p.ordinal()] = build(s, p);
            }
        }
    }

    private ModEffects() {
    }

    public static StatusEffect get(Substance s, Phase p) {
        return EFFECTS[s.ordinal()][p.ordinal()];
    }

    public static String uuid(String key) {
        return UUID.nameUUIDFromBytes(("narcotics:" + key).getBytes(StandardCharsets.UTF_8)).toString();
    }

    private static StatusEffect build(Substance s, Phase p) {
        StatusEffectType type = p == Phase.CRASH ? StatusEffectType.HARMFUL : StatusEffectType.BENEFICIAL;
        PhasedEffect e = new PhasedEffect(type, COLORS[s.ordinal()], s, p);
        double[] m = MODS[s.ordinal()][p.ordinal()];
        String key = s.id + "_" + p.name().toLowerCase();
        if (m[0] != 0.0D) {
            e.addAttributeModifier(EntityAttributes.GENERIC_MOVEMENT_SPEED, uuid(key + "_ms"), m[0],
                    EntityAttributeModifier.Operation.MULTIPLY_TOTAL);
        }
        if (m[1] != 0.0D) {
            e.addAttributeModifier(EntityAttributes.GENERIC_ATTACK_SPEED, uuid(key + "_as"), m[1],
                    EntityAttributeModifier.Operation.MULTIPLY_TOTAL);
        }
        return e;
    }

    public static void register() {
        for (Substance s : Substance.VALUES) {
            for (Phase p : Phase.values()) {
                Registry.register(Registry.STATUS_EFFECT,
                        Narcotics.id(s.id + "_" + p.name().toLowerCase()), get(s, p));
            }
        }
        Registry.register(Registry.STATUS_EFFECT, Narcotics.id("withdrawal"), WITHDRAWAL);
    }
}
