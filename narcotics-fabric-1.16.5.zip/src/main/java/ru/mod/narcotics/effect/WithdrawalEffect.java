package ru.mod.narcotics.effect;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectType;
import net.minecraft.entity.player.PlayerEntity;

public class WithdrawalEffect extends StatusEffect {
    public WithdrawalEffect() {
        super(StatusEffectType.HARMFUL, 0x4A5D3A);
        addAttributeModifier(EntityAttributes.GENERIC_ATTACK_SPEED, ModEffects.uuid("withdrawal_as"),
                -0.2D, EntityAttributeModifier.Operation.MULTIPLY_TOTAL);
        addAttributeModifier(EntityAttributes.GENERIC_MOVEMENT_SPEED, ModEffects.uuid("withdrawal_ms"),
                -0.1D, EntityAttributeModifier.Operation.MULTIPLY_TOTAL);
    }

    @Override
    public boolean canApplyUpdateEffect(int duration, int amplifier) {
        return duration % 100 == 0;
    }

    @Override
    public void applyUpdateEffect(LivingEntity entity, int amplifier) {
        if (!entity.world.isClient && entity instanceof PlayerEntity) {
            ((PlayerEntity) entity).addExhaustion(0.35F);
        }
    }
}
