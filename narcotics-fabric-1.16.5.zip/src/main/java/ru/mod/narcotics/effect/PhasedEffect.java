package ru.mod.narcotics.effect;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.AttributeContainer;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectType;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import ru.mod.narcotics.drug.DrugManager;
import ru.mod.narcotics.drug.Phase;
import ru.mod.narcotics.drug.Substance;

/** Marker effect for one phase of one substance. Chains to the next phase when it expires. */
public class PhasedEffect extends StatusEffect {
    private final Substance substance;
    private final Phase phase;

    public PhasedEffect(StatusEffectType type, int color, Substance substance, Phase phase) {
        super(type, color);
        this.substance = substance;
        this.phase = phase;
    }

    @Override
    public boolean canApplyUpdateEffect(int duration, int amplifier) {
        return duration % 20 == 0;
    }

    @Override
    public void applyUpdateEffect(LivingEntity entity, int amplifier) {
        // Runs on both sides. Particles are client-only, so the server does nothing here.
        if (entity.world.isClient) {
            entity.world.addParticle(phase == Phase.CRASH ? ParticleTypes.SMOKE : ParticleTypes.HAPPY_VILLAGER,
                    entity.getParticleX(0.5D), entity.getRandomBodyY(), entity.getParticleZ(0.5D), 0.0D, 0.02D, 0.0D);
        }
    }

    @Override
    public void onRemoved(LivingEntity entity, AttributeContainer attributes, int amplifier) {
        super.onRemoved(entity, attributes, amplifier);
        if (entity.world.isClient || !entity.isAlive() || !(entity instanceof ServerPlayerEntity)) {
            return;
        }
        DrugManager.onPhaseEnded((ServerPlayerEntity) entity, substance, phase);
    }
}
