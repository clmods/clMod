package ru.mod.narcotics.block;

import java.util.Map;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Material;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.TranslatableText;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import ru.mod.narcotics.item.InvUtil;

public class ChemistryTableBlock extends Block {
    public ChemistryTableBlock() {
        super(AbstractBlock.Settings.of(Material.METAL).strength(3.5F).sounds(BlockSoundGroup.METAL));
    }

    @Override
    public ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player,
                              Hand hand, BlockHitResult hit) {
        if (hand != Hand.MAIN_HAND) {
            return ActionResult.PASS;
        }
        if (world.isClient) {
            return ActionResult.SUCCESS;
        }
        ItemStack held = player.getStackInHand(Hand.MAIN_HAND);
        ChemRecipe r = ChemRecipes.forPrimary(held.getItem());
        if (r == null) {
            player.sendMessage(new TranslatableText("narcotics.table.hint"), true);
            return ActionResult.CONSUME;
        }
        for (Map.Entry<Item, Integer> e : r.needs.entrySet()) {
            int have = InvUtil.count(player, e.getKey());
            if (have < e.getValue()) {
                player.sendMessage(new TranslatableText("narcotics.table.missing",
                        e.getValue() - have, new TranslatableText(e.getKey().getTranslationKey())), true);
                return ActionResult.CONSUME;
            }
        }
        for (Map.Entry<Item, Integer> e : r.needs.entrySet()) {
            InvUtil.remove(player, e.getKey(), e.getValue());
        }
        InvUtil.give(player, new ItemStack(r.result, r.count));
        world.playSound(null, pos, SoundEvents.BLOCK_BREWING_STAND_BREW, SoundCategory.BLOCKS, 1.0F, 1.0F);
        ((ServerWorld) world).spawnParticles(ParticleTypes.SMOKE,
                pos.getX() + 0.5D, pos.getY() + 1.1D, pos.getZ() + 0.5D, 12, 0.2D, 0.1D, 0.2D, 0.01D);
        return ActionResult.CONSUME;
    }
}
