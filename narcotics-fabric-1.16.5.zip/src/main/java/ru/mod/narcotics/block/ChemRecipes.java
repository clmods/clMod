package ru.mod.narcotics.block;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.item.Item;
import net.minecraft.item.Items;
import ru.mod.narcotics.item.ModItems;

public final class ChemRecipes {
    public static final List<ChemRecipe> ALL = new ArrayList<ChemRecipe>();

    static {
        // Hold the first item in your main hand and right-click the table.
        ALL.add(new ChemRecipe(Items.COCOA_BEANS, ModItems.COCAINE_POWDER, 2)
                .need(Items.COCOA_BEANS, 4).need(Items.BONE_MEAL, 2).need(Items.BLAZE_POWDER, 1));
        ALL.add(new ChemRecipe(ModItems.COCAINE_POWDER, ModItems.SYRINGE_STIMULANT, 1)
                .need(ModItems.COCAINE_POWDER, 1).need(ModItems.SYRINGE_EMPTY, 1).need(Items.BLAZE_POWDER, 1));
        ALL.add(new ChemRecipe(ModItems.CANNABIS_BUD, ModItems.SYRINGE_HALLUCINOGEN, 1)
                .need(ModItems.CANNABIS_BUD, 3).need(ModItems.SYRINGE_EMPTY, 1).need(Items.BLAZE_POWDER, 1));
        ALL.add(new ChemRecipe(Items.SPIDER_EYE, ModItems.SYRINGE_DEPRESSANT, 1)
                .need(Items.SPIDER_EYE, 2).need(Items.ROTTEN_FLESH, 2)
                .need(ModItems.SYRINGE_EMPTY, 1).need(Items.BLAZE_POWDER, 1));
        ALL.add(new ChemRecipe(Items.POPPY, ModItems.SYRINGE_OPIOID, 1)
                .need(Items.POPPY, 6).need(ModItems.SYRINGE_EMPTY, 1).need(Items.BLAZE_POWDER, 1));
    }

    private ChemRecipes() {
    }

    public static ChemRecipe forPrimary(Item item) {
        for (ChemRecipe r : ALL) {
            if (r.primary == item) {
                return r;
            }
        }
        return null;
    }
}
