package ru.mod.narcotics.block;

import java.util.LinkedHashMap;
import java.util.Map;

import net.minecraft.item.Item;

/** Chemistry table recipe. The item in the main hand selects the recipe; everything is taken from the inventory. */
public final class ChemRecipe {
    public final Item primary;
    public final Item result;
    public final int count;
    public final Map<Item, Integer> needs = new LinkedHashMap<Item, Integer>();

    public ChemRecipe(Item primary, Item result, int count) {
        this.primary = primary;
        this.result = result;
        this.count = count;
    }

    public ChemRecipe need(Item item, int amount) {
        needs.put(item, amount);
        return this;
    }
}
