package ru.mod.narcotics.block;

import net.minecraft.block.Block;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.util.registry.Registry;
import ru.mod.narcotics.Narcotics;

public final class ModBlocks {
    public static final Block CHEMISTRY_TABLE = new ChemistryTableBlock();

    private ModBlocks() {
    }

    public static void register() {
        Registry.register(Registry.BLOCK, Narcotics.id("chemistry_table"), CHEMISTRY_TABLE);
        Registry.register(Registry.ITEM, Narcotics.id("chemistry_table"),
                new BlockItem(CHEMISTRY_TABLE, new Item.Settings().group(Narcotics.GROUP)));
    }
}
