package ru.mod.narcotics;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import ru.mod.narcotics.client.HallucinationClient;

@Environment(EnvType.CLIENT)
public class NarcoticsClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        HallucinationClient.init();
    }
}
