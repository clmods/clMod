package ru.mod.narcotics.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawableHelper;
import net.minecraft.entity.player.PlayerEntity;
import ru.mod.narcotics.drug.Phase;
import ru.mod.narcotics.drug.Substance;
import ru.mod.narcotics.effect.ModEffects;

/** Visual-only effects: tint overlay, FOV pulse, camera sway. Nothing here touches the server. */
@Environment(EnvType.CLIENT)
public final class HallucinationClient {
    private static float intensity;
    private static float target;
    private static float rush;
    private static float rushTarget;

    private HallucinationClient() {
    }

    public static float intensity() {
        return intensity;
    }

    public static float rush() {
        return rush;
    }

    public static void init() {
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            PlayerEntity p = mc.player;
            if (p == null || mc.world == null) {
                target = 0F;
                rushTarget = 0F;
            } else if (p.age % 5 == 0) { // status effects are polled 4 times per second
                target = hallucinogenLevel(p);
                rushTarget = p.hasStatusEffect(ModEffects.get(Substance.STIMULANT, Phase.PEAK)) ? 1F : 0F;
            }
            intensity += (target - intensity) * 0.06F;
            rush += (rushTarget - rush) * 0.10F;
            if (intensity < 0.002F) intensity = 0F;
            if (rush < 0.002F) rush = 0F;
        });

        HudRenderCallback.EVENT.register((matrices, tickDelta) -> {
            if (intensity <= 0.01F) {
                return;
            }
            MinecraftClient mc = MinecraftClient.getInstance();
            int alpha = (int) (70F * Math.min(1F, intensity));
            int color = (alpha << 24) | 0x7A3CFF;
            DrawableHelper.fill(matrices, 0, 0, mc.getWindow().getScaledWidth(),
                    mc.getWindow().getScaledHeight(), color);
        });
    }

    private static float hallucinogenLevel(PlayerEntity p) {
        if (p.hasStatusEffect(ModEffects.get(Substance.HALLUCINOGEN, Phase.PEAK))) return 1F;
        if (p.hasStatusEffect(ModEffects.get(Substance.HALLUCINOGEN, Phase.PLATEAU))) return 0.6F;
        if (p.hasStatusEffect(ModEffects.get(Substance.HALLUCINOGEN, Phase.CRASH))) return 0.2F;
        return 0F;
    }
}
