package ru.mod.narcotics.mixin;

import net.minecraft.server.network.ServerPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.mod.narcotics.drug.DrugData;

@Mixin(ServerPlayerEntity.class)
public abstract class ServerPlayerEntityMixin {
    // Keep tolerance after death / dimension change.
    @Inject(method = "copyFrom", at = @At("TAIL"))
    private void narcotics$copy(ServerPlayerEntity oldPlayer, boolean alive, CallbackInfo ci) {
        ((DrugData) (Object) this).narcotics$copyFrom((DrugData) oldPlayer);
    }
}
