package ru.mod.narcotics.mixin.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.mod.narcotics.client.HallucinationClient;

@Environment(EnvType.CLIENT)
@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
    @Inject(method = "getFov", at = @At("RETURN"), cancellable = true)
    private void narcotics$fov(Camera camera, float tickDelta, boolean changingFov,
                               CallbackInfoReturnable<Double> cir) {
        float k = HallucinationClient.intensity();
        float r = HallucinationClient.rush();
        if (k > 0F || r > 0F) {
            double pulse = Math.sin(System.currentTimeMillis() / 700.0D) * 7.0D * k;
            cir.setReturnValue(cir.getReturnValueD() + pulse + 8.0D * r);
        }
    }
}
