package ru.mod.narcotics.mixin;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.CompoundTag;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.mod.narcotics.drug.DrugData;
import ru.mod.narcotics.drug.Substance;

@Mixin(PlayerEntity.class)
public abstract class PlayerEntityMixin implements DrugData {
    private final int[] narcotics$tol = new int[Substance.COUNT];
    private final long[] narcotics$last = new long[Substance.COUNT];
    private final long[] narcotics$end = new long[Substance.COUNT];
    private final int[] narcotics$pct = new int[Substance.COUNT];

    @Override
    public int narcotics$getTolerance(Substance s) {
        return narcotics$tol[s.ordinal()];
    }

    @Override
    public void narcotics$setTolerance(Substance s, int value) {
        narcotics$tol[s.ordinal()] = Math.max(0, value);
    }

    @Override
    public long narcotics$getLastDose(Substance s) {
        return narcotics$last[s.ordinal()];
    }

    @Override
    public void narcotics$setLastDose(Substance s, long worldTime) {
        narcotics$last[s.ordinal()] = worldTime;
    }

    @Override
    public long narcotics$getPhaseEnd(Substance s) {
        return narcotics$end[s.ordinal()];
    }

    @Override
    public void narcotics$setPhaseEnd(Substance s, long worldTime) {
        narcotics$end[s.ordinal()] = worldTime;
    }

    @Override
    public int narcotics$getStrength(Substance s) {
        int v = narcotics$pct[s.ordinal()];
        return v <= 0 ? 100 : v;
    }

    @Override
    public void narcotics$setStrength(Substance s, int percent) {
        narcotics$pct[s.ordinal()] = percent;
    }

    @Override
    public void narcotics$copyFrom(DrugData other) {
        for (Substance s : Substance.VALUES) {
            narcotics$setTolerance(s, other.narcotics$getTolerance(s));
            narcotics$setLastDose(s, other.narcotics$getLastDose(s));
            narcotics$setPhaseEnd(s, 0L);
            narcotics$setStrength(s, other.narcotics$getStrength(s));
        }
    }

    @Inject(method = "writeCustomDataToTag", at = @At("TAIL"))
    private void narcotics$write(CompoundTag tag, CallbackInfo ci) {
        tag.putIntArray("NarcoTol", narcotics$tol);
        tag.putLongArray("NarcoLast", narcotics$last);
        tag.putLongArray("NarcoEnd", narcotics$end);
        tag.putIntArray("NarcoPct", narcotics$pct);
    }

    @Inject(method = "readCustomDataFromTag", at = @At("TAIL"))
    private void narcotics$read(CompoundTag tag, CallbackInfo ci) {
        int[] t = tag.getIntArray("NarcoTol");
        System.arraycopy(t, 0, narcotics$tol, 0, Math.min(t.length, narcotics$tol.length));
        long[] l = tag.getLongArray("NarcoLast");
        System.arraycopy(l, 0, narcotics$last, 0, Math.min(l.length, narcotics$last.length));
        long[] e = tag.getLongArray("NarcoEnd");
        System.arraycopy(e, 0, narcotics$end, 0, Math.min(e.length, narcotics$end.length));
        int[] p = tag.getIntArray("NarcoPct");
        System.arraycopy(p, 0, narcotics$pct, 0, Math.min(p.length, narcotics$pct.length));
    }
}
