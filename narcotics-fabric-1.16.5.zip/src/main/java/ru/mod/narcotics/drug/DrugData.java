package ru.mod.narcotics.drug;

/** Per-player drug state. Implemented on PlayerEntity by PlayerEntityMixin. */
public interface DrugData {
    int narcotics$getTolerance(Substance s);
    void narcotics$setTolerance(Substance s, int value);

    long narcotics$getLastDose(Substance s);
    void narcotics$setLastDose(Substance s, long worldTime);

    /** World time when the current phase should end; 0 = no active chain. */
    long narcotics$getPhaseEnd(Substance s);
    void narcotics$setPhaseEnd(Substance s, long worldTime);

    /** Strength of the last dose in percent (100 = pure). */
    int narcotics$getStrength(Substance s);
    void narcotics$setStrength(Substance s, int percent);

    void narcotics$copyFrom(DrugData other);
}
