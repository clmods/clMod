package ru.mod.narcotics.drug;

public enum Substance {
    //            id              peak  plateau crash  withdrawalAt  grace(ticks)
    STIMULANT   ("stimulant",     400,  2400,   1800,  4,            6000),
    HALLUCINOGEN("hallucinogen",  600,  3600,   600,   6,            12000),
    DEPRESSANT  ("depressant",    300,  3000,   1200,  4,            6000),
    OPIOID      ("opioid",        200,  2400,   2400,  3,            6000);

    public static final Substance[] VALUES = values();
    public static final int COUNT = VALUES.length;

    public final String id;
    /** Phase lengths in ticks: [PEAK, PLATEAU, CRASH]. */
    public final int[] ticks;
    /** Tolerance level at which withdrawal starts. */
    public final int withdrawalAt;
    /** Ticks after the last dose before withdrawal can start. */
    public final int grace;

    Substance(String id, int peak, int plateau, int crash, int withdrawalAt, int grace) {
        this.id = id;
        this.ticks = new int[]{peak, plateau, crash};
        this.withdrawalAt = withdrawalAt;
        this.grace = grace;
    }
}
