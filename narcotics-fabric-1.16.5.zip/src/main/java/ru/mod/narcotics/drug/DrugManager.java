package ru.mod.narcotics.drug;

import java.util.ArrayDeque;
import java.util.UUID;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.TranslatableText;
import ru.mod.narcotics.effect.ModEffects;

public final class DrugManager {
    private static final class Pending {
        final UUID player;
        final Substance substance;
        final Phase phase;

        Pending(UUID player, Substance substance, Phase phase) {
            this.player = player;
            this.substance = substance;
            this.phase = phase;
        }
    }

    private static final ArrayDeque<Pending> QUEUE = new ArrayDeque<Pending>();

    private DrugManager() {
    }

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (!QUEUE.isEmpty()) {
                drain(server);
            }
            int t = server.getTicks();
            if (t % 100 != 0) {
                return; // every 5 seconds at most
            }
            for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                // sharding: each player is checked once per ~20 seconds
                if ((t / 100 + p.getEntityId()) % 4 != 0) {
                    continue;
                }
                check(p);
            }
        });
    }

    private static void drain(MinecraftServer server) {
        Pending pe;
        while ((pe = QUEUE.poll()) != null) {
            ServerPlayerEntity p = server.getPlayerManager().getPlayer(pe.player);
            if (p != null && p.isAlive()) {
                startPhase(p, pe.substance, pe.phase);
            }
        }
    }

    // ---------------------------------------------------------------- doses

    public static float scale(LivingEntity e, Substance s) {
        if (!(e instanceof DrugData)) {
            return 1F;
        }
        DrugData d = (DrugData) e;
        float tol = Math.max(0.4F, 1F - 0.08F * d.narcotics$getTolerance(s));
        return tol * d.narcotics$getStrength(s) / 100F;
    }

    public static boolean isActive(LivingEntity e, Substance s) {
        for (Phase ph : Phase.values()) {
            if (e.hasStatusEffect(ModEffects.get(s, ph))) {
                return true;
            }
        }
        return false;
    }

    public static void dose(ServerPlayerEntity p, Substance s, int strengthPercent) {
        DrugData d = (DrugData) p;
        boolean wasActive = isActive(p, s);
        int tol = d.narcotics$getTolerance(s);

        d.narcotics$setPhaseEnd(s, 0L); // cancels the chain while old markers are removed
        for (Phase ph : Phase.values()) {
            p.removeStatusEffect(ModEffects.get(s, ph));
        }

        if (wasActive && tol >= s.withdrawalAt) {
            overdose(p);
        }

        d.narcotics$setTolerance(s, Math.min(tol + 1, 20));
        d.narcotics$setLastDose(s, p.world.getTime());
        d.narcotics$setStrength(s, strengthPercent);
        p.removeStatusEffect(ModEffects.WITHDRAWAL);
        startPhase(p, s, Phase.PEAK);
    }

    private static void overdose(ServerPlayerEntity p) {
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.WITHER, 200, 0, false, true, true));
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, 200, 0, false, false, true));
        p.sendMessage(new TranslatableText("narcotics.overdose"), true);
    }

    // --------------------------------------------------------------- phases

    /** Called from PhasedEffect.onRemoved (server side). */
    public static void onPhaseEnded(ServerPlayerEntity p, Substance s, Phase ended) {
        DrugData d = (DrugData) p;
        long end = d.narcotics$getPhaseEnd(s);
        if (end <= 0L || p.world.getTime() + 5 < end) {
            return; // removed early (milk, /effect clear, new dose): do not chain
        }
        Phase next = ended.next();
        if (next == null) {
            d.narcotics$setPhaseEnd(s, 0L);
            return;
        }
        QUEUE.add(new Pending(p.getUuid(), s, next));
    }

    private static void startPhase(ServerPlayerEntity p, Substance s, Phase ph) {
        DrugData d = (DrugData) p;
        int dur = Math.max(40, Math.round(s.ticks[ph.ordinal()] * scale(p, s)));
        d.narcotics$setPhaseEnd(s, p.world.getTime() + dur);
        p.addStatusEffect(new StatusEffectInstance(ModEffects.get(s, ph), dur, 0, false, false, true));
        companions(p, s, ph, dur);
    }

    private static void add(ServerPlayerEntity p, StatusEffect effect, int dur, int amp) {
        p.addStatusEffect(new StatusEffectInstance(effect, dur, amp, false, false, false));
    }

    private static void companions(ServerPlayerEntity p, Substance s, Phase ph, int dur) {
        switch (s) {
            case STIMULANT:
                if (ph == Phase.PEAK) {
                    add(p, StatusEffects.HASTE, dur, 1);
                    add(p, StatusEffects.HUNGER, dur, 0);
                } else if (ph == Phase.PLATEAU) {
                    add(p, StatusEffects.HASTE, dur, 0);
                } else {
                    add(p, StatusEffects.MINING_FATIGUE, dur, 0);
                    add(p, StatusEffects.WEAKNESS, dur, 0);
                }
                break;
            case HALLUCINOGEN:
                if (ph == Phase.PEAK) {
                    add(p, StatusEffects.NAUSEA, dur, 0);
                } else if (ph == Phase.PLATEAU) {
                    add(p, StatusEffects.NIGHT_VISION, dur, 0);
                } else {
                    add(p, StatusEffects.WEAKNESS, dur, 0);
                    add(p, StatusEffects.BLINDNESS, Math.min(dur, 60), 0);
                }
                break;
            case DEPRESSANT:
                if (ph == Phase.CRASH) {
                    add(p, StatusEffects.WEAKNESS, dur, 1);
                    add(p, StatusEffects.HUNGER, dur, 0);
                } else {
                    add(p, StatusEffects.RESISTANCE, dur, 0);
                }
                break;
            case OPIOID:
                if (ph == Phase.PEAK) {
                    add(p, StatusEffects.ABSORPTION, dur, 1);
                    add(p, StatusEffects.RESISTANCE, dur, 1);
                } else if (ph == Phase.PLATEAU) {
                    add(p, StatusEffects.ABSORPTION, dur, 0);
                    add(p, StatusEffects.RESISTANCE, dur, 0);
                } else {
                    add(p, StatusEffects.WEAKNESS, dur, 1);
                    add(p, StatusEffects.NAUSEA, dur, 0);
                    add(p, StatusEffects.MINING_FATIGUE, dur, 0);
                }
                break;
            default:
                break;
        }
    }

    // ----------------------------------------------------------- withdrawal

    private static void check(ServerPlayerEntity p) {
        DrugData d = (DrugData) p;
        long now = p.world.getTime();
        for (Substance s : Substance.VALUES) {
            int tol = d.narcotics$getTolerance(s);
            if (tol <= 0) {
                continue;
            }
            long since = now - d.narcotics$getLastDose(s);
            if (since > 48000L) { // tolerance decays by 1 per game day of abstinence
                tol--;
                d.narcotics$setTolerance(s, tol);
                d.narcotics$setLastDose(s, now - 24000L);
                since = 24000L;
            }
            if (tol >= s.withdrawalAt && since > s.grace && !isActive(p, s)) {
                if (!p.hasStatusEffect(ModEffects.WITHDRAWAL)) {
                    p.sendMessage(new TranslatableText("narcotics.withdrawal"), true);
                    p.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 200, 0, false, false, false));
                }
                p.addStatusEffect(new StatusEffectInstance(ModEffects.WITHDRAWAL, 600, 0, false, true, true));
            }
        }
    }
}
