package ru.mod.narcotics.drug;

public enum Phase {
    PEAK, PLATEAU, CRASH;

    public Phase next() {
        if (this == PEAK) return PLATEAU;
        if (this == PLATEAU) return CRASH;
        return null;
    }
}
