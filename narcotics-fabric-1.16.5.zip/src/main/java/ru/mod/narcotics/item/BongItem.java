package ru.mod.narcotics.item;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.UseAction;
import net.minecraft.world.World;
import ru.mod.narcotics.drug.DrugManager;
import ru.mod.narcotics.drug.Substance;

/** Reusable: burns one cannabis_bud from the inventory per use, wears out after 64 uses. */
public class BongItem extends Item {
    public BongItem(Settings settings) {
        super(settings);
    }

    @Override
    public int getMaxUseTime(ItemStack stack) {
        return 40;
    }

    @Override
    public UseAction getUseAction(ItemStack stack) {
        return UseAction.BOW;
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (!user.abilities.creativeMode && InvUtil.count(user, ModItems.CANNABIS_BUD) < 1) {
            return TypedActionResult.fail(stack);
        }
        user.setCurrentHand(hand);
        return TypedActionResult.consume(stack);
    }

    @Override
    public ItemStack finishUsing(ItemStack stack, World world, LivingEntity user) {
        if (!world.isClient && user instanceof ServerPlayerEntity) {
            ServerPlayerEntity player = (ServerPlayerEntity) user;
            boolean creative = player.abilities.creativeMode;
            if (creative || InvUtil.count(player, ModItems.CANNABIS_BUD) >= 1) {
                if (!creative) {
                    InvUtil.remove(player, ModItems.CANNABIS_BUD, 1);
                }
                DrugManager.dose(player, Substance.HALLUCINOGEN, 100);
                final Hand hand = player.getActiveHand();
                stack.damage(1, player, e -> e.sendToolBreakStatus(hand));
            }
        }
        return stack;
    }
}
