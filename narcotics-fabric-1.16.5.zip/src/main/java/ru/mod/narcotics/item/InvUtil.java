package ru.mod.narcotics.item;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public final class InvUtil {
    private InvUtil() {
    }

    public static int count(PlayerEntity p, Item item) {
        int total = 0;
        for (int i = 0; i < p.inventory.size(); i++) {
            ItemStack st = p.inventory.getStack(i);
            if (st.getItem() == item) {
                total += st.getCount();
            }
        }
        return total;
    }

    public static void remove(PlayerEntity p, Item item, int amount) {
        for (int i = 0; i < p.inventory.size() && amount > 0; i++) {
            ItemStack st = p.inventory.getStack(i);
            if (st.getItem() == item) {
                int take = Math.min(amount, st.getCount());
                st.decrement(take);
                amount -= take;
            }
        }
    }

    public static void give(PlayerEntity p, ItemStack stack) {
        p.inventory.insertStack(stack);
        if (!stack.isEmpty()) {
            p.dropItem(stack, false);
        }
    }
}
