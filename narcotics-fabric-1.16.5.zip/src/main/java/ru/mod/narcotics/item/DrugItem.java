package ru.mod.narcotics.item;

import java.util.function.Supplier;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.UseAction;
import net.minecraft.world.World;
import ru.mod.narcotics.drug.DrugManager;
import ru.mod.narcotics.drug.Substance;

/** Item that gives one dose of a substance after being held for a few ticks (RMB on yourself). */
public class DrugItem extends Item {
    private final Substance substance;
    private final int useTicks;
    private final UseAction action;
    private final Supplier<Item> leftover;
    private final float selfDamage;
    private final int strength;

    public DrugItem(Settings settings, Substance substance, int useTicks, UseAction action,
                    Supplier<Item> leftover, float selfDamage, int strength) {
        super(settings);
        this.substance = substance;
        this.useTicks = useTicks;
        this.action = action;
        this.leftover = leftover;
        this.selfDamage = selfDamage;
        this.strength = strength;
    }

    @Override
    public int getMaxUseTime(ItemStack stack) {
        return useTicks;
    }

    @Override
    public UseAction getUseAction(ItemStack stack) {
        return action;
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        user.setCurrentHand(hand);
        return TypedActionResult.consume(user.getStackInHand(hand));
    }

    @Override
    public ItemStack finishUsing(ItemStack stack, World world, LivingEntity user) {
        if (user instanceof PlayerEntity) {
            PlayerEntity player = (PlayerEntity) user;
            if (!world.isClient && user instanceof ServerPlayerEntity) {
                DrugManager.dose((ServerPlayerEntity) user, substance, strength);
                if (selfDamage > 0F) {
                    user.damage(DamageSource.GENERIC, selfDamage);
                }
            }
            if (!player.abilities.creativeMode) {
                stack.decrement(1);
                if (!world.isClient && leftover != null) {
                    InvUtil.give(player, new ItemStack(leftover.get()));
                }
            }
        }
        return stack;
    }
}
