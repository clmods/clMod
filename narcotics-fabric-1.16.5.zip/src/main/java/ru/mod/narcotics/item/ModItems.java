package ru.mod.narcotics.item;

import net.minecraft.item.Item;
import net.minecraft.util.UseAction;
import net.minecraft.util.registry.Registry;
import ru.mod.narcotics.Narcotics;
import ru.mod.narcotics.drug.Substance;

public final class ModItems {
    public static final Item CANNABIS_BUD = new Item(base());
    public static final Item SYRINGE_EMPTY = new Item(base().maxCount(16));

    public static final Item COCAINE_POWDER = new DrugItem(base(), Substance.STIMULANT, 16, UseAction.EAT, null, 0F, 100);
    public static final Item COCAINE_CUT = new DrugItem(base(), Substance.STIMULANT, 16, UseAction.EAT, null, 0F, 50);
    public static final Item JOINT = new DrugItem(base(), Substance.HALLUCINOGEN, 32, UseAction.EAT, null, 0F, 100);

    public static final Item SYRINGE_STIMULANT = syringe(Substance.STIMULANT);
    public static final Item SYRINGE_HALLUCINOGEN = syringe(Substance.HALLUCINOGEN);
    public static final Item SYRINGE_DEPRESSANT = syringe(Substance.DEPRESSANT);
    public static final Item SYRINGE_OPIOID = syringe(Substance.OPIOID);

    public static final Item BONG = new BongItem(base().maxCount(1).maxDamage(64));

    private ModItems() {
    }

    private static Item.Settings base() {
        return new Item.Settings().group(Narcotics.GROUP);
    }

    private static Item syringe(Substance s) {
        return new DrugItem(base().maxCount(1), s, 32, UseAction.BOW, () -> ModItems.SYRINGE_EMPTY, 1F, 100);
    }

    private static void reg(String id, Item item) {
        Registry.register(Registry.ITEM, Narcotics.id(id), item);
    }

    public static void register() {
        reg("cannabis_bud", CANNABIS_BUD);
        reg("joint", JOINT);
        reg("bong", BONG);
        reg("cocaine_powder", COCAINE_POWDER);
        reg("cocaine_cut", COCAINE_CUT);
        reg("syringe_empty", SYRINGE_EMPTY);
        reg("syringe_stimulant", SYRINGE_STIMULANT);
        reg("syringe_hallucinogen", SYRINGE_HALLUCINOGEN);
        reg("syringe_depressant", SYRINGE_DEPRESSANT);
        reg("syringe_opioid", SYRINGE_OPIOID);
    }
}
